"""
Asistente_Negocio.py  ·  Asistente de Negocios Inteligente con Voz
Integra: reconocimiento de voz · TTS · sistema de recomendación híbrido · Streamlit
"""

import streamlit as st
import speech_recognition as sr
import pyttsx3
import threading
import re
import time
import warnings
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from recomendador import (
    recomendacion_hibrida,
    recomendacion_colaborativa,
    recomendacion_contenido,
    recomendar_por_categoria,
    obtener_producto_por_nombre,
    registrar_interaccion,
    obtener_historial,
    calcular_metricas,
    PRODUCTOS,
    USUARIO_ACTIVO,
    MATRIZ_RATINGS,
)

warnings.filterwarnings("ignore")

# ===================== CONFIG =====================
st.set_page_config(
    page_title="BizAssist PRO",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ===================== SESSION STATE =====================
for key, default in {
    "messages": [],
    "usuario_id": USUARIO_ACTIVO,
    "ultima_rec": None,
    "voice_enabled": True,
    "metricas_cache": None,
    "ultimo_producto_id": None,
    "pagina": "inicio",
}.items():
    if key not in st.session_state:
        st.session_state[key] = default

# ===================== TTS =====================
@st.cache_resource
def get_tts_engine():
    try:
        engine = pyttsx3.init()
        engine.setProperty("rate", 155)
        engine.setProperty("volume", 0.9)
        for v in engine.getProperty("voices"):
            if any(x in v.name.lower() for x in ["spanish", "español", "mexican", "latin"]):
                engine.setProperty("voice", v.id)
                break
        return engine
    except Exception:
        return None

engine = get_tts_engine()

def speak(text: str):
    if not st.session_state.voice_enabled or not engine:
        return
    clean = re.sub(r"[*_#`]", "", text)[:300]
    threading.Thread(
        target=lambda: (engine.say(clean), engine.runAndWait()),
        daemon=True
    ).start()

def listen() -> str | None:
    rec = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            st.info("🎙️ Escuchando… habla ahora")
            rec.adjust_for_ambient_noise(source, duration=0.8)
            audio = rec.listen(source, timeout=6, phrase_time_limit=6)
        st.info("🔄 Procesando…")
        return rec.recognize_google(audio, language="es-MX")
    except sr.WaitTimeoutError:
        st.warning("⏰ No te escuché. Intenta de nuevo")
    except sr.UnknownValueError:
        st.warning("🤔 No entendí. ¿Puedes repetir?")
    except sr.RequestError:
        st.error("🌐 Error de conexión con el servicio de voz")
    except Exception as e:
        st.error(f"Error: {e}")
    return None

# ===================== INTENT DETECTION =====================
INTENTS = {
    "recomendar": [
        "recomiéndame", "recomienda", "recomiendame", "qué me sugieres",
        "que me sugieres", "qué debo comprar", "sugiéreme", "sugiereme",
        "qué comprar", "dame recomendaciones", "qué me conviene",
    ],
    "buscar_categoria": [
        "muéstrame", "muestrame", "quiero ver", "busca", "tienes",
        "hay algo de", "qué tienes en", "productos de", "artículos de",
    ],
    "ver_historial": [
        "mi historial", "qué compré", "que compre", "mis compras",
        "qué he visto", "mis productos", "historial",
    ],
    "info_producto": [
        "cuéntame sobre", "cuentame sobre", "información de", "informacion de",
        "detalles de", "qué es", "describe", "cómo es",
    ],
    "metricas": [
        "métricas", "metricas", "precisión", "precision", "rendimiento",
        "qué tan bueno", "evaluación", "evaluacion", "estadísticas",
    ],
    "ayuda": [
        "ayuda", "help", "qué puedes hacer", "que puedes hacer",
        "comandos", "cómo te uso", "instrucciones",
    ],
    "saludo": [
        "hola", "buenos días", "buenas tardes", "buenas noches",
        "hey", "qué tal",
    ],
}

CATEGORIAS_CONOCIDAS = [
    "electrónica", "electronica", "audio", "wearable", "periféricos",
    "perifericos", "fotografía", "fotografia", "almacenamiento",
    "impresión", "impresion", "accesorios", "laptop", "monitor",
    "teclado", "mouse", "bocina", "auricular", "cámara", "camara",
    "tablet", "smartwatch",
]

def detectar_intent(texto: str) -> tuple[str, str | None]:
    """Retorna (intent, entidad_extraída)."""
    t = texto.lower()

    for intent, frases in INTENTS.items():
        if any(f in t for f in frases):
            # Extraer entidad si aplica
            if intent == "buscar_categoria":
                for cat in CATEGORIAS_CONOCIDAS:
                    if cat in t:
                        return intent, cat.capitalize()
                # Última palabra como categoría
                palabras = t.split()
                return intent, palabras[-1].capitalize() if palabras else None

            if intent == "info_producto":
                patron = r"(?:sobre|de|es|describe)\s+(.+)"
                m = re.search(patron, t)
                return intent, m.group(1).strip().title() if m else None

            return intent, None

    # Sin intent reconocido → recomendar por defecto
    return "recomendar", None


# ===================== RESPUESTAS DEL ASISTENTE =====================
def responder(texto: str) -> str:
    intent, entidad = detectar_intent(texto)

    if intent == "saludo":
        r = "¡Hola! Soy tu asistente de negocios. Puedo recomendarte productos, mostrar tu historial o explicarte métricas del modelo. ¿Qué necesitas?"

    elif intent == "ayuda":
        r = ("Puedo hacer lo siguiente:\n"
             "• **Recomendar** productos personalizados\n"
             "• **Buscar** por categoría (ej. 'muéstrame laptops')\n"
             "• Mostrar tu **historial** de compras\n"
             "• Darte **información** de un producto\n"
             "• Ver las **métricas** del modelo de recomendación\n"
             "¡Solo dímelo con voz o escríbelo!")

    elif intent == "recomendar":
        recs = recomendacion_hibrida(st.session_state.usuario_id, top_n=5)
        st.session_state.ultima_rec = recs
        nombres = ", ".join(recs["nombre"].tolist()[:3])
        r = f"Basándome en tu perfil te recomiendo: {nombres}. ¿Quieres saber más sobre alguno?"

    elif intent == "buscar_categoria":
        if entidad:
            recs = recomendar_por_categoria(entidad, top_n=5)
            if recs.empty:
                r = f"No encontré productos en la categoría '{entidad}'. Intenta con: electrónica, audio, periféricos."
            else:
                st.session_state.ultima_rec = recs
                nombres = ", ".join(recs["nombre"].tolist())
                r = f"En {entidad} tengo: {nombres}. Aquí puedes ver los detalles."
        else:
            r = "¿Qué categoría buscas? Por ejemplo: laptops, audio, periféricos, fotografía."

    elif intent == "ver_historial":
        hist = obtener_historial(st.session_state.usuario_id)
        if hist.empty:
            r = "Aún no tienes historial de compras. ¡Te recomiendo que empieces a explorar productos!"
        else:
            nombres = ", ".join(hist["nombre"].tolist()[:3])
            r = f"Tu historial incluye: {nombres}. Puedes verlo completo en la sección de historial."

    elif intent == "info_producto":
        if entidad:
            prod = obtener_producto_por_nombre(entidad)
            if prod is not None:
                st.session_state.ultimo_producto_id = int(prod["id"])
                r = (f"**{prod['nombre']}**: {prod['descripcion'].capitalize()}. "
                     f"Precio: ${prod['precio']:,}. "
                     f"Calificación: {prod['calificacion']}/5. "
                     f"Marca: {prod['marca']}.")
            else:
                r = f"No encontré información sobre '{entidad}'. ¿Podrías ser más específico?"
        else:
            r = "¿Sobre qué producto quieres información?"

    elif intent == "metricas":
        if st.session_state.metricas_cache is None:
            with st.spinner("Calculando métricas del modelo…"):
                st.session_state.metricas_cache = calcular_metricas(k=5)
        m = st.session_state.metricas_cache
        r = (f"Métricas del modelo (K=5): "
             f"Precision@5 = {m['Precision@5']:.2%}, "
             f"Recall@5 = {m['Recall@5']:.2%}, "
             f"NDCG@5 = {m['NDCG@5']:.2%}. "
             f"Cobertura del catálogo: {m['cobertura']:.0%}.")
    else:
        r = "No entendí bien. Intenta decir 'recomiéndame algo', 'muéstrame laptops' o 'ayuda'."

    return r


# ===================== COMPONENTES UI =====================
def tarjeta_producto(row, show_score_col: str = None):
    score_txt = ""
    if show_score_col and show_score_col in row.index and not pd.isna(row[show_score_col]):
        score_txt = f"<div style='font-size:0.8rem;color:#6c757d;'>Score: {row[show_score_col]:.3f}</div>"

    categoria_color = {
        "Electrónica": "#4361ee", "Audio": "#7209b7", "Wearable": "#f72585",
        "Periféricos": "#4cc9f0", "Fotografía": "#3a0ca3", "Almacenamiento": "#480ca8",
        "Impresión": "#560bad", "Accesorios": "#b5179e",
    }.get(row["categoria"], "#333")

    st.markdown(f"""
    <div style='
        background: white;
        border: 1px solid #e9ecef;
        border-radius: 12px;
        padding: 1rem;
        margin: 0.4rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        transition: transform 0.15s;
    '>
        <div style='display:flex; justify-content:space-between; align-items:flex-start;'>
            <div style='font-weight:700; font-size:1rem; color:#212529;'>{row['nombre']}</div>
            <span style='background:{categoria_color};color:white;padding:2px 8px;
                         border-radius:20px;font-size:0.72rem;'>{row['categoria']}</span>
        </div>
        <div style='color:#6c757d; font-size:0.85rem; margin:0.3rem 0;'>{row['descripcion'].capitalize()}</div>
        <div style='display:flex; justify-content:space-between; align-items:center; margin-top:0.5rem;'>
            <div style='font-size:1.2rem; font-weight:700; color:#2d6a4f;'>${row['precio']:,}</div>
            <div>{'⭐' * int(round(row['calificacion']))} <span style='font-size:0.8rem;color:#6c757d;'>{row['calificacion']}</span></div>
        </div>
        <div style='font-size:0.75rem; color:#adb5bd; margin-top:0.3rem;'>Marca: {row['marca']}</div>
        {score_txt}
    </div>
    """, unsafe_allow_html=True)


def mostrar_recomendaciones(df: pd.DataFrame, titulo: str, score_col: str = None):
    st.markdown(f"### {titulo}")
    if df.empty:
        st.info("No se encontraron productos.")
        return
    cols = st.columns(min(len(df), 3))
    for i, (_, row) in enumerate(df.iterrows()):
        with cols[i % 3]:
            tarjeta_producto(row, score_col)


def pagina_metricas():
    st.markdown("## 📊 Evaluación del Modelo")
    if st.button("🔄 Calcular métricas", type="primary"):
        with st.spinner("Evaluando modelo…"):
            st.session_state.metricas_cache = calcular_metricas(k=5)

    if st.session_state.metricas_cache:
        m = st.session_state.metricas_cache
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Precision@5",  f"{m['Precision@5']:.2%}")
        col2.metric("Recall@5",     f"{m['Recall@5']:.2%}")
        col3.metric("NDCG@5",       f"{m['NDCG@5']:.2%}")
        col4.metric("Cobertura",    f"{m['cobertura']:.0%}")

        # Gráfica de barras de métricas
        fig = go.Figure(go.Bar(
            x=["Precision@5", "Recall@5", "NDCG@5", "Cobertura"],
            y=[m["Precision@5"], m["Recall@5"], m["NDCG@5"], m["cobertura"]],
            marker_color=["#4361ee", "#7209b7", "#f72585", "#4cc9f0"],
            text=[f"{v:.1%}" for v in [m["Precision@5"], m["Recall@5"], m["NDCG@5"], m["cobertura"]]],
            textposition="outside",
        ))
        fig.update_layout(
            title="Métricas del sistema de recomendación",
            yaxis=dict(tickformat=".0%", range=[0, 1.1]),
            height=350,
            plot_bgcolor="white",
        )
        st.plotly_chart(fig, use_container_width=True)

        # Distribución de ratings
        st.markdown("### 📈 Distribución de interacciones usuario-producto")
        flat = MATRIZ_RATINGS.values.flatten()
        flat = flat[flat > 0]
        fig2 = px.histogram(
            x=flat, nbins=20,
            labels={"x": "Rating", "count": "Frecuencia"},
            title="Distribución de ratings en el dataset",
            color_discrete_sequence=["#4361ee"],
        )
        fig2.update_layout(height=300, plot_bgcolor="white")
        st.plotly_chart(fig2, use_container_width=True)

    # Análisis de sesgos / ética
    st.markdown("---")
    st.markdown("### ⚖️ Análisis de Sesgos y Ética")
    col_e1, col_e2 = st.columns(2)
    with col_e1:
        st.markdown("""
        **Sesgos identificados:**
        - 📦 **Popularidad**: productos con más interacciones tienden a aparecer más
        - 🧑‍🤝‍🧑 **Grupo demográfico**: el dataset simulado tiene 3 perfiles fijos
        - 🏷️ **Precio**: productos caros pueden ser sub-recomendados a usuarios nuevos
        
        **Mitigaciones implementadas:**
        - ✅ Filtrado híbrido para balancear popularidad vs contenido
        - ✅ Score normalizado (MinMaxScaler)
        - ✅ Cobertura mínima de catálogo medida
        """)
    with col_e2:
        st.markdown("""
        **Privacidad de datos:**
        - 🔒 Datos almacenados solo en sesión (sin persistencia a disco por defecto)
        - 👤 Identificador de usuario anonimizado (`u01`, `u02`…)
        - 📵 No se comparten datos con terceros
        
        **Plan de escalado:**
        - Migrar a base de datos PostgreSQL / MongoDB
        - Modelos re-entrenados semanalmente (MLOps pipeline)
        - Monitoreo de drift de datos con Evidently AI
        """)


# ===================== LAYOUT PRINCIPAL =====================
st.markdown("""
<style>
    [data-testid="stSidebar"] { background: #0f0f1a; }
    [data-testid="stSidebar"] * { color: #e0e0e0 !important; }
    .block-container { padding-top: 1.5rem; }
    .stChatMessage { border-radius: 12px; }
</style>
""", unsafe_allow_html=True)

# ── SIDEBAR ──────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🤖 BizAssist PRO")
    st.markdown("*Asistente de Negocios con IA*")
    st.divider()

    st.session_state.voice_enabled = st.toggle(
        "🔊 Voz habilitada", value=st.session_state.voice_enabled
    )

    st.divider()
    st.markdown("**👤 Usuario activo**")
    usuarios = [f"u{i:02d}" for i in range(1, 11)]
    st.session_state.usuario_id = st.selectbox("Selecciona usuario demo", usuarios, index=0)

    st.divider()
    st.markdown("**📌 Navegación**")
    paginas = {
        "🏠 Inicio / Chat":         "inicio",
        "✨ Recomendaciones":       "recs",
        "📦 Catálogo":              "catalogo",
        "🕒 Historial":             "historial",
        "📊 Métricas y Ética":      "metricas",
    }
    for label, key in paginas.items():
        if st.button(label, use_container_width=True, key=f"nav_{key}"):
            st.session_state.pagina = key
            st.rerun()

    st.divider()
    st.caption("UCA 3 · Procesamiento de Lenguaje Natural y APIs de Voz")

# ── CONTENIDO PRINCIPAL ──────────────────────────────────
pagina = st.session_state.pagina

# ── PÁGINA: INICIO / CHAT ────────────────────────────────
if pagina == "inicio":
    st.title("🤖 Asistente de Negocios Inteligente")
    st.caption("Pregúntame por recomendaciones, productos o métricas del modelo")

    # Botón de voz grande
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("🎤  HABLAR CON EL ASISTENTE", type="primary", use_container_width=True):
            texto_voz = listen()
            if texto_voz:
                st.success(f"📝 Dijiste: **{texto_voz}**")
                st.session_state.messages.append({"role": "user", "content": f"🎤 {texto_voz}"})
                respuesta = responder(texto_voz)
                st.session_state.messages.append({"role": "assistant", "content": respuesta})
                speak(respuesta)
                time.sleep(0.4)
                st.rerun()

    st.markdown("---")

    # Historial de chat
    for msg in st.session_state.messages[-12:]:
        with st.chat_message(msg["role"], avatar="🧑" if msg["role"] == "user" else "🤖"):
            st.markdown(msg["content"])

    # Si hay recomendaciones pendientes, mostrarlas
    if st.session_state.ultima_rec is not None:
        rec_df = st.session_state.ultima_rec
        score_col = next(
            (c for c in ["score_hibrido", "score_cf", "score_cb"] if c in rec_df.columns),
            None
        )
        mostrar_recomendaciones(rec_df, "🎯 Productos Recomendados", score_col)

    # Input de texto
    prompt = st.chat_input("✏️ Escribe tu pregunta…")
    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        respuesta = responder(prompt)
        st.session_state.messages.append({"role": "assistant", "content": respuesta})
        speak(respuesta)
        st.rerun()

# ── PÁGINA: RECOMENDACIONES ──────────────────────────────
elif pagina == "recs":
    st.title("✨ Recomendaciones Personalizadas")
    uid = st.session_state.usuario_id

    tab1, tab2, tab3 = st.tabs(["🔀 Híbrido", "👥 Colaborativo", "📄 Basado en Contenido"])

    with tab1:
        st.markdown(f"Recomendaciones híbridas para **{uid}** (60% CF + 40% CB)")
        recs = recomendacion_hibrida(uid, top_n=6)
        mostrar_recomendaciones(recs, "", "score_hibrido")

    with tab2:
        st.markdown(f"Usuarios similares a **{uid}** también compraron:")
        recs_cf = recomendacion_colaborativa(uid, top_n=6)
        mostrar_recomendaciones(recs_cf, "", "score_cf")

    with tab3:
        prod_id = st.selectbox(
            "Selecciona producto base",
            PRODUCTOS["id"].tolist(),
            format_func=lambda x: PRODUCTOS[PRODUCTOS["id"] == x]["nombre"].values[0]
        )
        recs_cb = recomendacion_contenido(prod_id, top_n=6)
        mostrar_recomendaciones(recs_cb, f"Similares a: {PRODUCTOS[PRODUCTOS['id']==prod_id]['nombre'].values[0]}", "score_cb")

    # Mapa de calor de similitud
    st.markdown("---")
    st.markdown("### 🗺️ Mapa de similitud entre usuarios (muestra)")
    from sklearn.metrics.pairwise import cosine_similarity
    muestra = MATRIZ_RATINGS.iloc[:8]
    sim = cosine_similarity(muestra.values)
    fig = px.imshow(
        sim,
        x=muestra.index.tolist(),
        y=muestra.index.tolist(),
        color_continuous_scale="Blues",
        title="Similitud coseno entre usuarios",
        zmin=0, zmax=1,
    )
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

# ── PÁGINA: CATÁLOGO ─────────────────────────────────────
elif pagina == "catalogo":
    st.title("📦 Catálogo de Productos")

    # Filtros
    col_f1, col_f2, col_f3 = st.columns(3)
    with col_f1:
        cats = ["Todas"] + sorted(PRODUCTOS["categoria"].unique().tolist())
        cat_sel = st.selectbox("Categoría", cats)
    with col_f2:
        precio_max = st.slider("Precio máximo ($)", 500, 25000, 25000, step=500)
    with col_f3:
        cal_min = st.slider("Calificación mínima", 1.0, 5.0, 4.0, step=0.1)

    df_filtrado = PRODUCTOS.copy()
    if cat_sel != "Todas":
        df_filtrado = df_filtrado[df_filtrado["categoria"] == cat_sel]
    df_filtrado = df_filtrado[
        (df_filtrado["precio"] <= precio_max) &
        (df_filtrado["calificacion"] >= cal_min)
    ]

    st.markdown(f"**{len(df_filtrado)} productos encontrados**")

    # Gráfica de precios por categoría
    fig = px.box(
        PRODUCTOS, x="categoria", y="precio",
        color="categoria", title="Distribución de precios por categoría",
        labels={"precio": "Precio ($)", "categoria": "Categoría"},
    )
    fig.update_layout(height=350, showlegend=False, plot_bgcolor="white")
    st.plotly_chart(fig, use_container_width=True)

    cols = st.columns(3)
    for i, (_, row) in enumerate(df_filtrado.iterrows()):
        with cols[i % 3]:
            tarjeta_producto(row)
            if st.button(f"💾 Registrar interés", key=f"reg_{row['id']}"):
                registrar_interaccion(st.session_state.usuario_id, int(row["id"]), 4.5)
                st.success("✅ Interés registrado")

# ── PÁGINA: HISTORIAL ────────────────────────────────────
elif pagina == "historial":
    st.title("🕒 Mi Historial de Compras")
    uid = st.session_state.usuario_id
    hist = obtener_historial(uid)

    if hist.empty:
        st.info("No tienes historial aún. Ve al catálogo y registra interés en productos.")
    else:
        st.markdown(f"**{len(hist)} productos** en tu historial")
        fig = px.bar(
            hist, x="nombre", y="mi_rating",
            color="categoria", title=f"Ratings de {uid}",
            labels={"mi_rating": "Mi Rating", "nombre": "Producto"},
        )
        fig.update_layout(height=350, plot_bgcolor="white", xaxis_tickangle=-30)
        st.plotly_chart(fig, use_container_width=True)

        cols = st.columns(3)
        for i, (_, row) in enumerate(hist.iterrows()):
            with cols[i % 3]:
                tarjeta_producto(row, "mi_rating")

# ── PÁGINA: MÉTRICAS ─────────────────────────────────────
elif pagina == "metricas":
    pagina_metricas()

# ── FOOTER ───────────────────────────────────────────────
st.markdown("---")
st.caption("🤖 **BizAssist PRO** · Sistema de Recomendación Híbrido · Streamlit + scikit-learn · UCA 3")

"""
recomendador.py
Motor de recomendación híbrido para el Asistente de Negocios Inteligente.
Combina filtrado colaborativo (usuario-usuario) y filtrado basado en contenido.
"""

import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

# ===================== DATASET SIMULADO =====================
# En un proyecto real esto vendría de una DB o CSV externo

PRODUCTOS = pd.DataFrame([
    {"id": 1,  "nombre": "Laptop Gamer X1",       "categoria": "Electrónica",  "precio": 22000, "marca": "TechPro",   "calificacion": 4.5, "descripcion": "laptop gaming alto rendimiento"},
    {"id": 2,  "nombre": "Laptop Ultrabook Z3",    "categoria": "Electrónica",  "precio": 18000, "marca": "SlimTech",  "calificacion": 4.3, "descripcion": "laptop delgada ligera oficina"},
    {"id": 3,  "nombre": "Auriculares Noise Pro",  "categoria": "Audio",        "precio": 3500,  "marca": "SoundMax",  "calificacion": 4.7, "descripcion": "auriculares cancelacion ruido bluetooth"},
    {"id": 4,  "nombre": "Smartwatch Fitness S2",  "categoria": "Wearable",     "precio": 2800,  "marca": "FitBand",   "calificacion": 4.2, "descripcion": "smartwatch deportivo monitor salud"},
    {"id": 5,  "nombre": "Teclado Mecánico RGB",   "categoria": "Periféricos",  "precio": 1200,  "marca": "KeyMaster", "calificacion": 4.6, "descripcion": "teclado mecanico gaming rgb backlight"},
    {"id": 6,  "nombre": "Monitor 4K 27 pulgadas", "categoria": "Electrónica",  "precio": 8500,  "marca": "ViewMax",   "calificacion": 4.4, "descripcion": "monitor 4k alta resolucion diseño"},
    {"id": 7,  "nombre": "Mouse Inalámbrico Pro",  "categoria": "Periféricos",  "precio": 950,   "marca": "ClickPro",  "calificacion": 4.1, "descripcion": "mouse inalambrico ergonomico precision"},
    {"id": 8,  "nombre": "Tablet CreativePad 10",  "categoria": "Electrónica",  "precio": 7200,  "marca": "CreateTab", "calificacion": 4.3, "descripcion": "tablet dibujo digital diseño creativo"},
    {"id": 9,  "nombre": "Bocina Bluetooth Tower", "categoria": "Audio",        "precio": 2200,  "marca": "SoundMax",  "calificacion": 4.5, "descripcion": "bocina bluetooth potente buen sonido"},
    {"id": 10, "nombre": "Cámara Mirrorless M50",  "categoria": "Fotografía",   "precio": 15000, "marca": "PhotoPro",  "calificacion": 4.8, "descripcion": "camara mirrorless fotografia profesional"},
    {"id": 11, "nombre": "Mochila Tech Backpack",  "categoria": "Accesorios",   "precio": 850,   "marca": "CarryOn",   "calificacion": 4.0, "descripcion": "mochila laptop USB charge antirrobo"},
    {"id": 12, "nombre": "Hub USB-C 7 en 1",       "categoria": "Periféricos",  "precio": 680,   "marca": "ConnectAll","calificacion": 4.2, "descripcion": "hub usbc puertos hdmi sd card"},
    {"id": 13, "nombre": "SSD Externo 1TB",        "categoria": "Almacenamiento","precio": 1800, "marca": "SpeedDisk", "calificacion": 4.6, "descripcion": "disco solido externo portatil veloz"},
    {"id": 14, "nombre": "Impresora Láser Color",  "categoria": "Impresión",    "precio": 5500,  "marca": "PrintMax",  "calificacion": 4.1, "descripcion": "impresora laser color wifi doble cara"},
    {"id": 15, "nombre": "Webcam HD 1080p Pro",    "categoria": "Periféricos",  "precio": 1400,  "marca": "CamView",   "calificacion": 4.4, "descripcion": "webcam hd videoconferencias streaming"},
])

# Interacciones usuario-producto: rating 1-5 (0 = no interactuó)
np.random.seed(42)
N_USUARIOS = 30
N_PRODUCTOS = len(PRODUCTOS)

MATRIZ_RATINGS = pd.DataFrame(
    np.zeros((N_USUARIOS, N_PRODUCTOS), dtype=float),
    index=[f"u{i:02d}" for i in range(1, N_USUARIOS + 1)],
    columns=PRODUCTOS["id"].tolist()
)

# Patrones de compra simulados (grupos de usuarios con gustos similares)
grupos = {
    "gamers":      (range(1, 11),  [1, 3, 5, 6, 7]),   # laptops gaming, periféricos
    "creativos":   (range(11, 21), [8, 10, 6, 3, 2]),   # tablets, cámaras
    "profesional": (range(21, 31), [2, 15, 14, 13, 11]),# laptops oficina, accesorios
}

for grupo, (usuarios, prods_preferidos) in grupos.items():
    for uid in usuarios:
        uid_str = f"u{uid:02d}"
        # Productos preferidos con rating alto
        for pid in prods_preferidos:
            MATRIZ_RATINGS.loc[uid_str, pid] = np.random.uniform(3.5, 5.0)
        # Algunos productos random con rating bajo
        otros = [p for p in PRODUCTOS["id"].tolist() if p not in prods_preferidos]
        random_prods = np.random.choice(otros, size=3, replace=False)
        for pid in random_prods:
            MATRIZ_RATINGS.loc[uid_str, pid] = np.random.uniform(1.0, 3.0)

# Usuario activo demo (simula el usuario que usa la app)
USUARIO_ACTIVO = "u01"

# ===================== MOTOR DE RECOMENDACIÓN =====================

def recomendacion_colaborativa(usuario_id: str, top_n: int = 5) -> pd.DataFrame:
    """
    Filtrado colaborativo usuario-usuario.
    Encuentra usuarios similares y recomienda productos que ellos valoraron alto.
    """
    matriz = MATRIZ_RATINGS.copy()
    
    # Similitud coseno entre usuarios
    sim_matrix = cosine_similarity(matriz.values)
    sim_df = pd.DataFrame(sim_matrix, index=matriz.index, columns=matriz.index)
    
    if usuario_id not in sim_df.index:
        usuario_id = USUARIO_ACTIVO
    
    # Top 5 usuarios más similares (excluyendo el mismo)
    similares = sim_df[usuario_id].drop(usuario_id).nlargest(5)
    
    # Productos que el usuario YA vio/compró
    ya_vistos = set(
        col for col in matriz.columns
        if matriz.loc[usuario_id, col] > 0
    )
    
    # Puntaje ponderado de productos no vistos
    scores = {}
    for prod_id in matriz.columns:
        if prod_id in ya_vistos:
            continue
        score = 0.0
        peso_total = 0.0
        for uid_sim, sim_score in similares.items():
            rating = matriz.loc[uid_sim, prod_id]
            if rating > 0:
                score += sim_score * rating
                peso_total += sim_score
        if peso_total > 0:
            scores[prod_id] = score / peso_total
    
    if not scores:
        return PRODUCTOS.head(top_n)
    
    top_ids = sorted(scores, key=scores.get, reverse=True)[:top_n]
    result = PRODUCTOS[PRODUCTOS["id"].isin(top_ids)].copy()
    result["score_cf"] = result["id"].map(scores)
    return result.sort_values("score_cf", ascending=False)


def recomendacion_contenido(producto_id: int, top_n: int = 5) -> pd.DataFrame:
    """
    Filtrado basado en contenido.
    Dado un producto, encuentra los más similares por categoría, precio y calificación.
    """
    features = PRODUCTOS[["precio", "calificacion"]].copy()
    scaler = MinMaxScaler()
    features_norm = scaler.fit_transform(features)
    
    # Encode categoría (one-hot)
    cat_dummies = pd.get_dummies(PRODUCTOS["categoria"])
    feature_matrix = np.hstack([features_norm, cat_dummies.values])
    
    sim = cosine_similarity(feature_matrix)
    idx = PRODUCTOS[PRODUCTOS["id"] == producto_id].index
    
    if len(idx) == 0:
        return PRODUCTOS.head(top_n)
    
    idx = idx[0]
    scores = list(enumerate(sim[idx]))
    scores = sorted(scores, key=lambda x: x[1], reverse=True)
    scores = [s for s in scores if s[0] != idx][:top_n]
    
    top_indices = [s[0] for s in scores]
    result = PRODUCTOS.iloc[top_indices].copy()
    result["score_cb"] = [s[1] for s in scores]
    return result


def recomendacion_hibrida(usuario_id: str, producto_id: int = None, top_n: int = 5, 
                           alpha: float = 0.6) -> pd.DataFrame:
    """
    Recomendación híbrida: combina CF (alpha) y CB (1-alpha).
    alpha=0.6 → 60% colaborativo, 40% contenido
    """
    cf_recs = recomendacion_colaborativa(usuario_id, top_n=top_n * 2)
    
    if producto_id is None:
        # Usar el último producto visto por el usuario
        vistos = {
            col: MATRIZ_RATINGS.loc[usuario_id, col]
            for col in MATRIZ_RATINGS.columns
            if MATRIZ_RATINGS.loc[usuario_id, col] > 0
        }
        if vistos:
            producto_id = max(vistos, key=vistos.get)
        else:
            return cf_recs.head(top_n)
    
    cb_recs = recomendacion_contenido(producto_id, top_n=top_n * 2)
    
    # Combinar scores
    scaler = MinMaxScaler()
    
    cf_scores = {}
    if "score_cf" in cf_recs.columns:
        vals = cf_recs["score_cf"].values.reshape(-1, 1)
        cf_scores = dict(zip(cf_recs["id"], scaler.fit_transform(vals).flatten()))
    
    cb_scores = {}
    if "score_cb" in cb_recs.columns:
        vals = cb_recs["score_cb"].values.reshape(-1, 1)
        cb_scores = dict(zip(cb_recs["id"], scaler.fit_transform(vals).flatten()))
    
    all_ids = set(cf_scores.keys()) | set(cb_scores.keys())
    hybrid = {
        pid: alpha * cf_scores.get(pid, 0) + (1 - alpha) * cb_scores.get(pid, 0)
        for pid in all_ids
    }
    
    top_ids = sorted(hybrid, key=hybrid.get, reverse=True)[:top_n]
    result = PRODUCTOS[PRODUCTOS["id"].isin(top_ids)].copy()
    result["score_hibrido"] = result["id"].map(hybrid)
    return result.sort_values("score_hibrido", ascending=False)


def recomendar_por_categoria(categoria: str, top_n: int = 5) -> pd.DataFrame:
    """Filtra y ordena productos de una categoría por calificación."""
    cat_lower = categoria.lower()
    mask = PRODUCTOS["categoria"].str.lower().str.contains(cat_lower, na=False)
    result = PRODUCTOS[mask].sort_values("calificacion", ascending=False).head(top_n)
    if result.empty:
        # Búsqueda en descripción
        mask2 = PRODUCTOS["descripcion"].str.lower().str.contains(cat_lower, na=False)
        result = PRODUCTOS[mask2].sort_values("calificacion", ascending=False).head(top_n)
    return result


def obtener_producto_por_nombre(nombre: str) -> pd.Series | None:
    """Busca un producto por nombre parcial."""
    nombre_lower = nombre.lower()
    mask = PRODUCTOS["nombre"].str.lower().str.contains(nombre_lower, na=False)
    result = PRODUCTOS[mask]
    return result.iloc[0] if not result.empty else None


def registrar_interaccion(usuario_id: str, producto_id: int, rating: float):
    """Registra una interacción (en producción esto iría a base de datos)."""
    if usuario_id in MATRIZ_RATINGS.index and producto_id in MATRIZ_RATINGS.columns:
        MATRIZ_RATINGS.loc[usuario_id, producto_id] = rating


def obtener_historial(usuario_id: str) -> pd.DataFrame:
    """Devuelve los productos que el usuario ha visto/comprado."""
    vistos = MATRIZ_RATINGS.loc[usuario_id]
    vistos = vistos[vistos > 0]
    if vistos.empty:
        return pd.DataFrame()
    result = PRODUCTOS[PRODUCTOS["id"].isin(vistos.index)].copy()
    result["mi_rating"] = vistos.values
    return result.sort_values("mi_rating", ascending=False)


# ===================== MÉTRICAS DE EVALUACIÓN =====================

def calcular_metricas(k: int = 5) -> dict:
    """
    Calcula Precision@K, Recall@K y una aproximación de NDCG@K
    usando train/test split sobre la matriz de ratings.
    """
    # Split: 80% train, 20% test
    train_mask = np.random.rand(*MATRIZ_RATINGS.shape) > 0.2
    train = MATRIZ_RATINGS.where(train_mask, 0)
    test = MATRIZ_RATINGS.where(~train_mask, 0)
    
    precisions, recalls, ndcgs = [], [], []
    
    for uid in train.index[:10]:  # evaluar sobre 10 usuarios para velocidad
        # Items relevantes en test (rating >= 3.5)
        relevantes = set(
            col for col in test.columns
            if test.loc[uid, col] >= 3.5
        )
        if not relevantes:
            continue
        
        # Recomendaciones top-K (usando filtrado colaborativo)
        recs = recomendacion_colaborativa(uid, top_n=k)
        recomendados = set(recs["id"].tolist())
        
        hits = len(relevantes & recomendados)
        precision = hits / k if k > 0 else 0
        recall = hits / len(relevantes) if relevantes else 0
        
        # NDCG simplificado
        dcg = sum(
            1 / np.log2(i + 2)
            for i, pid in enumerate(recs["id"].tolist())
            if pid in relevantes
        )
        idcg = sum(1 / np.log2(i + 2) for i in range(min(len(relevantes), k)))
        ndcg = dcg / idcg if idcg > 0 else 0
        
        precisions.append(precision)
        recalls.append(recall)
        ndcgs.append(ndcg)
    
    return {
        f"Precision@{k}": round(np.mean(precisions), 4) if precisions else 0,
        f"Recall@{k}":    round(np.mean(recalls), 4) if recalls else 0,
        f"NDCG@{k}":      round(np.mean(ndcgs), 4) if ndcgs else 0,
        "usuarios_evaluados": len(precisions),
        "cobertura":          round(len(PRODUCTOS) / N_PRODUCTOS, 4),
    }
